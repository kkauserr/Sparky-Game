let music;
let posnoise;
let negnoise;
let clicknoise;
let mainstage = "main menu setup";
let buttons1;
let buttons2;
let buttons3;
let buttons4;
let buttons5;

let startButtons;

let QuitButtons;
let QuitResume;
let QuitMainMenu;
let QuitOptions; //placeholder

let poolData = [200,35*9,6,3,0];//[ballX, ballY, dx, dy,paddleY]
let poolLives = 5;
let poolScore = 0;
let poolMaxScore = 0;

let coinsX = 30;
let coinsY = 30;
let coinsR = 20;
let coinsTimer = 30;
let coinsScore = 0;
let coinsMaxScore = 0;
let coinsButtons;

let escapeData = []; //dx,dy,x,y,r
let escapeTimer = 3;
let escapeScore = 0;
let escapeIntensity = 0.1;
let escapeMaxScore = 0;

let cbg = "#64171A"
let cbg2 = "#8BBAE9"

let cbuttons = "#121212"
let cbb = "#00000000"

let ctext = "#FFFFFF"
let cstroke = "#FFFFFF"
let cspecial = "#FBBF0A"
let cx = "#42D9C8"

function preload(){
  music = loadSound('music_zapsplat_easy_cheesy.mp3')
posnoise=loadSound('zapsplat_multimedia_game_tone_sci_fi_futuristic_beep_positive_003_54380.mp3')
negnoise=loadSound('zapsplat_multimedia_game_sound_digital_retro_simple_negative_error_001_80624.mp3')
clicknoise=loadSound('zapsplat_technology_studio_speaker_active_power_switch_click_002_68874.mp3')
}
function setup() {
  let canvasWidth = 70;
  createCanvas(canvasWidth*16, canvasWidth*9);
  textFont("Helvetica");
  textStyle(BOLD)
  background(cbg);
  music.play();
  
  //textAlign(LEFT,BASELINE)
}

function draw() {
  textAlign(LEFT,BASELINE)
  if (mainstage=="main menu setup") {
    textAlign(LEFT,BASELINE)
    removeElements();
    background(cbg);
    fill(ctext)
    //fill("black")
    
    let titleTextSize = 80;
    let buttonsTextSize = "48px";
    let leftMargin = 50;
    let upMargin = 120;
    let spc = 80;
    
    textSize(titleTextSize);
    text("Sparky's Game Menu☀️😈🔱", leftMargin,upMargin);
    upMargin +=50;
    
    buttons1 = createButton("ASU Pool🏊‍♂️🏄‍♂️");
    buttons1.style("font-family", "Helvetica");
    buttons1.style("font-size", buttonsTextSize);
    buttons1.style("background-color",cbuttons)
    buttons1.style("color",ctext)
    buttons1.style("border-color",cbb)
    buttons1.position(leftMargin,upMargin);
    upMargin +=spc;
    
    buttons2 = createButton("Barrett Coin🪙");
    buttons2.style("font-family", "Helvetica");
    buttons2.style("font-size", buttonsTextSize);
    buttons2.style("background-color",cbuttons)
    buttons2.style("color",ctext)
    buttons2.style("border-color",cbb)
    buttons2.position(leftMargin,upMargin);
    upMargin +=spc;
    
    buttons3 = createButton("Sparky Escape👣🏃‍♂️");
    buttons3.style("font-family", "Helvetica");
    buttons3.style("font-size", buttonsTextSize);
    buttons3.style("background-color",cbuttons)
    buttons3.style("color",ctext)
    buttons3.style("border-color",cbb)
    buttons3.position(leftMargin,upMargin);
    upMargin +=spc;
    
    buttons4 = createButton("by jkauser");
    buttons4.style("font-family", "Helvetica");
    buttons4.style("font-size", buttonsTextSize);
    buttons4.style("background-color",cbuttons)
    buttons4.style("color",ctext)
    buttons4.style("border-color",cbb)
    buttons4.position(leftMargin,upMargin);
    upMargin +=spc;    

    buttons1.mousePressed(b1);
    buttons2.mousePressed(b2)
    buttons3.mousePressed(b3);
    buttons4.mousePressed(b4);
    //button5.mousePressed(b5);
    
    mainstage = "main menu";
  }
  if (mainstage == "main menu") {
    //do nothing
  }
  
  if (mainstage == "pool setup") {
    removeElements();
    clear();
    background(cbg);
    
    //background("#00aaaa");
    //background("light blue");
    //line(width/2,0,width/2,height);
    textSize(100);
    text("ASU Pool Game",width/2-295,height/2-50);
   
    QuitSetup();
    
    startSetup()
    
    poolData = [200,35*9,6,3,0];//[ballX, ballY, dx, dy,paddleY]
    poolLives = 5;
    poolScore = 0;
    poolMaxScore = 0;
    
    mainstage = "pool start"
    
    textSize(30)
  }
  if (mainstage == "pool restart") {
    removeElements();
    clear();
    background(cbg);
    
    QuitSetup();
    
    poolData = [200,35*9,6,3,0];//[ballX, ballY, dx, dy,paddleY]
    poolLives = 5;
    poolScore = 0;
    poolMaxScore = 0;
    
    mainstage = "Pitchfork food "
  }
  
  if (mainstage == "Pitchfork food ") {
    let r=15;
    let length = 120;
    let barX = 100;
    clear()
    background(cbg);
    
    stroke(cstroke)
    fill(cbg2)
    rect(50,50,width-100,height-100)
    
    //noStroke()
    
    circle(poolData[0],poolData[1],r*2);
    
    textAlign(CENTER,CENTER)
    fill("black")
    text(poolLives,poolData[0],poolData[1])
    
    let goalX = 1000;
    let goalY = height/2
    let goalR = 25;
    
    fill(cspecial)
    circle(goalX,goalY,goalR*2)
    
    const xmax = 70*16-50;
    const xmin = 50;
    const ymax = 70*9-50
    
    fill("black")
    
    let recty = min(max(mouseY,xmin+length/2),ymax-length/2)-length/2;
    
    rect(100,recty,10,length);
    
    nfx = poolData[0]+poolData[2]*0.3; //nextframe x
    nfy = poolData[1]+poolData[3]*0.3
    
    if (barX-r < nfx && nfx < barX+r+10 && (mouseY-length/2-r)<nfy && nfy<(mouseY+length/2+r)) {
      poolData[2] = abs(poolData[2]);
      let dx = poolData[2]; let dy = poolData[3];
      let poolSpeed = sqrt(dx*dx + dy*dy);
      let angle =atan2(dy,dx);
      let adjust = (poolData[1]-mouseY)/length
      angle += adjust;
      
      poolData[2] = poolSpeed*cos(angle);
      poolData[3] = poolSpeed*sin(angle);
    }
    
    let dGoal = sqrt((nfx-goalX)**2+(nfy-goalY)**2)
    
    if (dGoal<goalR+r+5) {
      poolScore++;
      playPosNoise();
      let dx = poolData[2]; let dy = poolData[3];
      let poolSpeed = sqrt(dx*dx + dy*dy);
      poolSpeed *=1.03;
      
      let angle = atan2(poolData[0]-goalX,poolData[1]-goalY);
      
      poolData[2] = poolSpeed*cos(angle);
      poolData[3] = poolSpeed*sin(angle);
      
      if (nfx<goalX) poolData[2] = -abs(poolData[2]);
      if (nfx>goalX) poolData[2] = abs(poolData[2]);
      
      if (nfy<goalY) poolData[3] = -abs(poolData[3]);
      if (nfy>goalY) poolData[3] = abs(poolData[3]);
      
    }
    
    if (poolData[0]>xmax-r) poolData[2]*=-1;
    if (poolData[0]<xmin+r) { 
      poolData[2]*=-1;
      poolLives--;
    }
    
    if (poolData[1]>ymax-r || poolData[1]<xmin+r) poolData[3]*=-1;
    
    poolData[0] += poolData[2];
    poolData[1] += poolData[3];
    
    if (poolScore>poolMaxScore) poolMaxScore=poolScore;
    
    textAlign(LEFT,BASELINE)
    textSize(30)
    text("balls: "+poolLives,50,40);
    text("scored: "+poolScore,400,40)
    text("high score: "+poolMaxScore,750,40)
    
    if (poolLives <=0) {
      playNegNoise();
        mainstage = "Pitchfork food  over"
        
        fill("black")
        textSize(100);
    
        text("Game Over",width/2-245,height/2-20)
        textAlign(CENTER,CENTER)
        
        restartSetup()
    }
  }
  
  if (mainstage == "coins setup") {
    removeElements();
    clear();
    background(cbg);
    //line(width/2,0,width/2,height);
    textSize(100);
    text("Barrett Coin Game",width/2-390,height/2-50);
   
    QuitSetup();
    
    startSetup()
    
    coinsX = random(70*15)+35;
    coinsY = random(70*8)+35;
    coinsR = random(40, 100);
    coinsTimer = 30;
    coinsScore = 0;
    
    mainstage = "coins start"
    
    textSize(30)
  }
  if (mainstage == "coins restart") {
    removeElements();
    clear();
    background(cbg);
   
    QuitSetup();
    
    
    coinsX = random(70*15)+35;
    coinsY = random(70*8)+35;
    coinsR = random(40, 100);
    coinsTimer = 30;
    coinsScore = 0;
    
    mainstage = "coins game"
    
    textSize(30)
  }
  if (mainstage == "coins game") {
    background(cbg);
    //coinsTimer
    fill(cbuttons)
    textAlign(CENTER, CENTER);
    textSize(50);
    text(coinsTimer, width/16, height/10);
    
    fill(cspecial)
    noStroke()
    circle(coinsX, coinsY, coinsR);
    
    fill(ctext)
    
    if (frameCount % 60 == 0 && coinsTimer > 0) {
      coinsTimer --;
    }
    if (coinsTimer == 0) {
      playNegNoise();
      removeElements();
      clear();
      background(cbg)
      text("Game Over",width/2,height/2-50);
      
      textSize(40)
      text("score: " + coinsScore, width/2, height/2+100);
      text("high score: " + coinsMaxScore, width/2, height/2+150)
      
      if (coinsScore==coinsMaxScore) text("new high score!", width/2, height/2+200)
      
      restartSetup()
      
      mainstage = "coins game over"
    }

    //coinsScore
    if (coinsTimer!=0) {
      textSize(50);
      if (coinsScore>coinsMaxScore) coinsMaxScore=coinsScore;
      text("score: " + coinsScore, width/2+200, 40);
      text("high score: " + coinsMaxScore, width/2-200, 40)
    }

    //coins
    var distance = dist(mouseX, mouseY, coinsX,coinsY);

    if (distance <= coinsR/2 && coinsTimer != 0) {
       coinsX = random(70*15)+35;
      coinsY = random(70*8-100)+35;
      coinsR = random(40, 100);
      coinsScore += 1;
      playPosNoise();
    }
  }
  
  if (mainstage == "escape setup") {
    removeElements();
    clear();
    background(cbg);
    //background("#00aaaa");
    //line(width/2,0,width/2,height);
    textSize(100);
    text("Sparky Escape game",width/2-430,height/2-50);
   
    QuitSetup();
    
    startSetup()
    
    escapeData = [];
    escapeTimer = 3;
    escapeIntensity = 0.1;
    escapeScore = 0;
    
    mainstage = "escape start"
    
    textSize(30)
  }
  if (mainstage == "escape restart") {
    removeElements();
    clear();
    background(cbg);
   
    QuitSetup();
    
    escapeData = [];
    escapeTimer = 3;
    escapeIntensity = 0.1;
    escapeScore = 0;
    
    mainstage = "escape game"
    
    textSize(30)
  }
  
  if (mainstage == "escape game") {
    textAlign(LEFT,BASELINE)
    clear();
    background(cbg);
    let mr = 7.5;
    
    fill(cbg)
    stroke(ctext)
    rect(50,50,width-100,height-100)
    
    noStroke()
    fill(ctext)
    text("escapes in: "+escapeTimer,50,40);
    text("scored: "+escapeScore,400,40)
    text("high score: "+escapeMaxScore,750,40)
    
    const xmax = 70*16-50;
    const xmin = 50;
    const ymax = 70*9-50
    
    let mx = min(max(mouseX,xmin+mr),xmax-mr);
    let my = min(max(mouseY,xmin+mr),ymax-mr);
    fill(cx)
    circle(mx,my,mr*2);
    fill(cspecial);
    
    if (frameCount % 60 == 0 && escapeTimer > 0) {
      escapeTimer--;
      escapeScore++;
      if (escapeScore>escapeMaxScore) escapeMaxScore=escapeScore;
    }
    
    if (escapeTimer==0) {
      let zone=100;
      let v = 1+random(5,10)*2*escapeIntensity;
      let r = random(10,20)+10*escapeIntensity;
      
      for (let i=0;i<1+10*escapeIntensity;i++) {
        let dir = random(0,2*PI);
    
        if ((mx+cos(dir)*zone>50+r)&&(mx+cos(dir)*zone<16*70-50-r)&&(my+sin(dir)*zone>50+r)&&(my+sin(dir)*zone<9*70-50-r)) {
          escapeData.push([cos(dir)*v,sin(dir)*v,cos(dir)*zone+mx,sin(dir)*zone+my,r])
        }
        else i--;
      }
      escapeTimer = 10;
      escapeIntensity+=0.03;
    }
    
    for (let i=0;i<escapeData.length;i++) {
      let r = escapeData[i][4];
      circle(escapeData[i][2],escapeData[i][3],r*2);
      if (escapeData[i][2]>xmax-r || escapeData[i][2]<xmin+r) escapeData[i][0]*=-1;
      if (escapeData[i][3]>ymax-r || escapeData[i][3]<xmin+r) escapeData[i][1]*=-1;
      escapeData[i][2]+=escapeData[i][0];
      escapeData[i][3]+=escapeData[i][1];
    }
    fill("white")
    
    for (let i=0;i<escapeData.length;i++) {
      let r = escapeData[i][4];
      let dx = mx-escapeData[i][2];
      let dy = my-escapeData[i][3];
      if (sqrt(dx*dx+dy*dy)<r+mr/2) {
        playNegNoise();
        mainstage = "escape game over"
        
        fill(ctext)
        textSize(100);
    
        text("Game Over",width/2-245,height/2-20)
        textAlign(CENTER,CENTER)
        
        restartSetup()
      }
    }
  }
  
  if (matchAll(mainstage,"Quit").length!=0) {
    QuitButton.hide();
    QuitMainMenu.show();
    QuitResume.show();
  }
  
}

function restartGame() {
  if (matchAll(mainstage, "over").length!=0) {
    switch(mainstage) {
      case "escape game over":
        mainstage = "escape restart";
        break;
      case "coins game over":
        mainstage = "coins restart"
        break;
      case "Pitchfork food  over":
        mainstage = "pool restart"
        break; 
    }
  }
  resumeFunc()
  restartButton.hide();
}

function startGame() {
  if (matchAll(mainstage, "start").length!=0) {
    switch(mainstage) {
      case "escape start":
        mainstage = "escape game";
        break;
      case "coins start":
        mainstage = "coins game"
        break;
      case "pool start":
        mainstage = "Pitchfork food "
        break; 
    }
    startButton.hide();
  }
}

function b1() {
  if (mainstage=="main menu") 
    playClick();
    mainstage = "pool setup";
}
function b2() {
  if (mainstage=="main menu") 
    playClick();
  mainstage = "coins setup";
}
function b3() {
  if (mainstage=="main menu") 
    playClick();
  mainstage = "escape setup";
}
function b4() {
  print("b4");//placeholder
  //if (mainstage=="main menu") 
  //mainstage = "options setup";
}
function b5() {
  print("b5");//placeholder
}

function QuitSetup() {
  let mid = width/2-40;
  //let  =
  QuitButton = createButton("Quit");
  QuitButton.style("font-family", "Bahnschrift Light");
  QuitButton.style("font-size", "25px");
  QuitButton.style("background-color",cbuttons)
  QuitButton.style("color",ctext)
  QuitButton.style("border-color",cbb)
  QuitButton.position (1000,10);
  
  QuitResume = createButton("Resume");
  QuitResume.style("font-family", "Bahnschrift Light");
  QuitResume.style("font-size", "25px");
  QuitResume.style("background-color",cbuttons)
  QuitResume.style("color",ctext)
  QuitResume.style("border-color",cbb)
  QuitResume.position (mid,200);
  
  QuitMainMenu = createButton("Main Menu");
  QuitMainMenu.style("font-family", "Bahnschrift Light");
  QuitMainMenu.style("font-size", "25px");
  QuitMainMenu.style("background-color",cbuttons)
  QuitMainMenu.style("color",ctext)
  QuitMainMenu.style("border-color",cbb)
  QuitMainMenu.position (mid,250);
  
  QuitButton.mousePressed(QuitFunc);
  QuitResume.mousePressed(resumeFunc);
  QuitMainMenu.mousePressed(mainMenuFunc);
  QuitResume.hide();
  QuitMainMenu.hide();
}

function restartSetup() {
  restartButton = createButton("re-play");
  restartButton.style("font-family", "Helvetica");
  restartButton.style("font-size", "48px");
  restartButton.position(width/2-90,height/2);
  
  restartButton.style("background-color",cbuttons)
  restartButton.style("color",ctext)
  restartButton.style("border-color",cbb)

  restartButton.mousePressed(restartGame)
}

function startSetup() {
  startButton = createButton("Play");
  startButton.style("font-family", "Helvetica");
  startButton.style("font-size", "48px");
  startButton.position(width/2-65,height/2);
  
  startButton.style("background-color",cbuttons)
  startButton.style("color",ctext)
  startButton.style("border-color",cbb)

  startButton.mousePressed(startGame)
}

function QuitFunc() {
  background("#ffffff44")
  switch(mainstage) {
    case "Pitchfork food ":
      mainstage="pool Quit";
      break;
    case "coins game":
      mainstage="coins Quit";
      break;
    case "escape game":
      mainstage="escape Quit";
      break;
  }
  
  QuitButton.hide();
  QuitResume.show();
  QuitMainMenu.show();
}

function resumeFunc() {
  QuitResume.hide();
  QuitMainMenu.hide();
  QuitButton.show()
  //QuitOptions.hide();
  
  switch(mainstage) {
    case "pool Quit":
      mainstage="Pitchfork food ";
      break;
    case "coins Quit":
      mainstage="coins game";
      break;
    case "escape Quit":
      mainstage="escape game";
      break;
  }
}

function mainMenuFunc() {
  mainstage = "main menu setup";
  QuitResume.hide();
  QuitMainMenu.hide();
}
  
function keyPressed() {
  if (keyCode === ESCAPE) {
    if (matchAll(mainstage,"Quit").length!=0) { //if Quitd, then resume 
      resumeFunc();
      return;
    }
    if (matchAll(mainstage,"game").length!=0) {//if gaming, then Quit 
      QuitFunc();
      return;
    }
    if (matchAll(mainstage,"start").length!=0) {//if gaming, then Quit 
      QuitFunc();
      return;
    }
  }
}
function playClick(){
  clicknoise.play();
}
function playPosNoise(){
  posnoise.play();
}
function playNegNoise(){
  negnoise.play();
}
